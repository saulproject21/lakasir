<?php

Namespace App\Repositories;

use App\Abstracts\Repository as RepositoryAbstract;

class TestRepository extends RepositoryAbstract
{
    protected string $model = 'App\Models\Test';
}
