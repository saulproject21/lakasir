<?php

namespace App\Repositories;

use App\Abstracts\Repository as RepositoryAbstract;

class Unit extends RepositoryAbstract
{
    protected string $model = 'App\Models\Unit';
}
