<?php

namespace App\DataTables;

use App\Abstracts\LaTable;

class DefaultTable extends LaTable
{
}
