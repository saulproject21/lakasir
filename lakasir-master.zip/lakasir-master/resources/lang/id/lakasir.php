<?php

return [
    'apps' => 'Aplikasi',
    'title' => 'Lakasir',
    'supported' => 'Di Dukung Penuh Oleh',
    'free_pos_software' => 'Software Kasir Gratis',
    'version' => 'Versi',
];
