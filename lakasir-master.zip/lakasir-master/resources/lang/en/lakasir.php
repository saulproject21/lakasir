<?php

return [
    'apps' => 'Applications',
    'title' => 'Lakasir',
    'supported' => 'Full Support By',
    'free_pos_software' => 'Free Point Of Sale Software',
    'version' => 'Version',
];
