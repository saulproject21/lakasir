<template>
  <div>

  </div>
</template>

<script>
export default {
  name: '',

  props: {

  },

  data() {
    return {

    }
  },

  methods: {

  },

  mounted() {
  }
}

</script>
