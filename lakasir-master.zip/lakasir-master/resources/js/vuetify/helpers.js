const helpers = {
  auth: {
    token: localStorage.getItem('bearer-token')
  },
}

export default helpers
