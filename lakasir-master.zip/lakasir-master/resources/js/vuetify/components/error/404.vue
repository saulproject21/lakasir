<template>
  <div class="d-flex justify-center">
    <h3 class="align-self-center">(404) Page NotFound</h3>
  </div>
</template>

<script>
export default {};
</script>
