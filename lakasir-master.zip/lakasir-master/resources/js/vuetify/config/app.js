const app = {
  logo: 'http://lakasir.deb/assets/lakasir-transparent.png'
}
export default app;
