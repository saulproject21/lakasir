import items from './../../../modules/items';

export default {
  namespaced: true,
  actions: items.actions,
  mutations: items.mutations,
  state: items.state
}

