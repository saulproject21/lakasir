import carts from './../../../modules/carts';

export default {
  namespaced: true,
  actions: carts.actions,
  mutations: carts.mutations,
  state: carts.state,
  getters: carts.getters
}


