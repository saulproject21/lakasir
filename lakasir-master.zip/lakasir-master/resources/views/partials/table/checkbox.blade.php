<div class="checkbox">
  <input type="checkbox" class="select-row" value="{{ $model->id }}" id="{{ $id = \Str::random() }}"/>
  <label for="{{ $id }}"></label>
</div>
