<span data-toggle="tooltip" title="{{ is_null($date) ? '' : $date }}">
  {!! is_null($date) ? '&mdash;' : $date !!}
</span>
