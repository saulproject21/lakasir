<span>
  @if (isset($delete))
  <a class="btn btn-primary delete-row" id="{{ $model->id }}"
    data-confirm=" {{ __('app.global.suredelete') }}" data-method="DELETE" href="{{ $delete }}"> {{ __('app.global.delete') }}</a>
  @endif
</span>
