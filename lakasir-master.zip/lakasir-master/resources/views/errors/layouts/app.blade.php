<!DOCTYPE html>
<html lang="{{ get_lang() }}">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width" />
    <title>App.blade</title>
  </head>
  <body>
    body
  </body>
</html>
