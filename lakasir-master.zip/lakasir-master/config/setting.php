<?php
return [
    'image' => [
        'empty' => '/assets/shop.png'
    ],
    'profile' => [
        'image_empty' => '/assets/man-2.png'
    ]
];
