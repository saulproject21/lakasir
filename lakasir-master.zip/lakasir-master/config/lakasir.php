<?php

return [
    'installed' => env('INSTALL', false),
    'logo-sm' => '/assets/lakasir-sm.png',
    'logo-full' => '/assets/lakasir-full.png',
    'logo-github' => '/assets/lakasir-github.png',
    'logo-transparent' => '/assets/lakasir-transparent.png',
    'appname' => 'Lakasir',
    'version' => '1.0-beta'
];
